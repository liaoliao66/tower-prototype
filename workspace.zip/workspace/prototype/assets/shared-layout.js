﻿/**
 * 通信铁塔检测系统 — PC端共享布局
 * 包含：侧边栏菜单、顶部导航栏、页面框架
 */
const MENU = [
  { id:'gzt', label:'工作台', icon:'fa-house', items:[
    {id:'dashboard', label:'工作台首页', href:'../../工作台/工作台首页/pc_dashboard.html'},
    {id:'workflow', label:'流程中心', href:'../../工作台/流程中心/pc_workflow.html'},
  ]},
  { id:'grzx', label:'个人中心', icon:'fa-user', items:[
    {id:'profile', label:'我的信息', href:'../../个人中心/我的信息/pc_profile.html'},
    {id:'messages', label:'消息中心', href:'../../个人中心/消息中心/pc_messages.html'},
    {id:'notices', label:'通知公告', href:'../../个人中心/通知公告/pc_notices.html'},
    {id:'logs', label:'登录日志', href:'../../个人中心/登录日志/pc_logs.html'},
  ]},
  { id:'htb', label:'合同部管理', icon:'fa-file-contract', items:[
    {id:'order_list', label:'订单管理', href:'../../合同部管理/订单管理/pc_order_list.html'},
    {id:'order_dispatch', label:'派单管理', href:'../../合同部管理/派单管理/pc_order_dispatch.html'},
    {id:'order_tracking', label:'派单跟踪', href:'../../合同部管理/派单跟踪/pc_order_tracking.html'},
    {id:'order_reports', label:'报告查阅', href:'../../合同部管理/报告查阅/pc_order_reports.html'},
  ]},
  { id:'yxgl', label:'营销管理', icon:'fa-handshake', items:[
    {id:'customer_list', label:'客户管理', href:'../../营销管理/客户管理/pc_customer_list.html'},
    {id:'project_list', label:'工程管理', href:'../../营销管理/工程管理/pc_project_list.html'},
    {id:'company_info', label:'检测单位管理', href:'../../营销管理/检测单位管理/pc_company_info.html'},
  ]},
  { id:'gysgl', label:'供应商管理', icon:'fa-truck', items:[
    {id:'supplier_list', label:'供应商名录', href:'../../供应商管理/供应商名录/pc_supplier_list.html'},
  ]},
  { id:'yqsb', label:'仪器设备管理', icon:'fa-microscope', items:[
    {id:'device_list', label:'设备信息', href:'../../仪器设备管理/设备信息/pc_device_list.html'},
    {id:'device_out', label:'设备出库', href:'../../仪器设备管理/设备出库/pc_device_out_list.html'},
    {id:'device_in', label:'设备入库', href:'../../仪器设备管理/设备入库/pc_device_in_list.html'},
    {id:'device_ledger', label:'出入库台账', href:'../../仪器设备管理/出入库台账/pc_device_ledger.html'},
  ]},
  { id:'ttjcpz', label:'铁塔基础配置', icon:'fa-sliders', items:[
    {id:'config_standard', label:'标准规范', href:'../../铁塔基础配置/标准规范/pc_config_standard.html'},
    {id:'config_tower_type', label:'铁塔类型', href:'../../铁塔基础配置/铁塔类型/pc_config_tower_type.html'},
    {id:'config_wind', label:'区域风压', href:'../../铁塔基础配置/区域风压/pc_config_wind.html'},
    {id:'config_segment', label:'塔段类型', href:'../../铁塔基础配置/塔段类型/pc_config_segment.html'},
    {id:'task_template_list', label:'任务模板管理', href:'../../任务模板配置/任务模板管理/pc_task_template_list.html'},
    {id:'report_template_list', label:'报告模板管理', href:'../../报告模板配置/报告模板管理/pc_report_template_list.html'},
  ]},
  { id:'jcsj', label:'基础数据', icon:'fa-database', items:[
    {id:'data_antenna', label:'天线数据', href:'../../基础数据/天线数据/pc_data_antenna.html'},
    {id:'data_site', label:'站点数据', href:'../../基础数据/站点数据/pc_data_site.html'},
    {id:'data_segment_style', label:'塔段样式信息', href:'../../基础数据/塔段样式管理/pc_data_segment_style.html'},
    {id:'data_tower', label:'铁塔信息', href:'../../基础数据/铁塔信息/pc_data_tower.html'},
  ]},
  { id:'jcyw', label:'铁塔检测业务', icon:'fa-tower-broadcast', items:[
    {id:'task_list', label:'检测任务', href:'../../铁塔检测业务/检测任务/pc_task_list.html'},
    {id:'task_data', label:'检测数据录入', href:'../../铁塔检测业务/检测数据录入/pc_task_data.html#tower-spec'},
    {id:'report_generate', label:'报告编制', href:'../../铁塔检测业务/报告编制/report-list.html'},
    {id:'print_apply', label:'打印申请', href:'../../铁塔检测业务/打印申请/pc_print_apply_list.html'},
    {id:'print_audit', label:'打印审批', href:'../../铁塔检测业务/打印审批/pc_print_audit_list.html'},
    {id:'print_ledger', label:'打印台账', href:'../../铁塔检测业务/打印台账/pc_print_ledger.html'},
  ]},
  { id:'yyjsc', label:'运营驾驶舱 · 扩展', icon:'fa-chart-line', items:[
    {id:'cockpit', label:'数据看板', href:'../../运营驾驶舱/数据看板/pc_cockpit.html'},
  ]},
  { id:'xtgl', label:'系统管理', icon:'fa-gear', items:[
    {id:'system_users', label:'用户管理', href:'../../系统管理/用户管理/pc_system_users.html'},
    {id:'system_roles', label:'角色管理', href:'../../系统管理/角色管理/pc_system_roles.html'},
    {id:'system_logs', label:'操作日志', href:'../../系统管理/操作日志/pc_system_logs.html'},
  ]},
];

function buildSidebar(activeId) {
  let html = `<div class="layout-sidebar" id="sidebar">
  <div class="sidebar-logo">
    <i class="fa-solid fa-tower-broadcast"></i>
    <span class="logo-text">铁塔检测系统</span>
  </div>
  <nav class="sidebar-nav">`;
  for (const g of MENU) {
    const hasActive = g.items.some(i => i.id === activeId);
    html += `<div class="menu-group${hasActive ? ' open' : ''}">
      <div class="menu-group-title" onclick="this.parentElement.classList.toggle('open')">
        <span><i class="fa-solid ${g.icon} group-icon"></i>${g.label}</span>
        <i class="fa-solid fa-chevron-right chevron"></i>
      </div>
      <div class="menu-group-items">`;
    for (const item of g.items) {
      html += `<a class="menu-item${item.id === activeId ? ' active' : ''}" href="${item.href}">${item.label}</a>`;
    }
    html += `</div></div>`;
  }
  html += `</nav>
  <div style="padding:12px 20px;border-top:1px solid rgba(255,255,255,0.08)">
    <a href="../../系统管理/登录页/pc_login.html" style="color:rgba(255,255,255,0.45);font-size:12px;text-decoration:none;display:flex;align-items:center;gap:6px"><i class="fa-solid fa-right-from-bracket"></i>退出登录</a>
  </div></div>`;
  return html;
}

function buildTopNav(breadcrumbArr, userName) {
  userName = userName || '张伟';
  let bc = '<div class="breadcrumb"><a href="../../工作台/工作台首页/pc_dashboard.html"><i class="fa-solid fa-house" style="font-size:13px"></i></a>';
  if (breadcrumbArr && breadcrumbArr.length) {
    for (let i = 0; i < breadcrumbArr.length; i++) {
      bc += '<span class="bc-sep">/</span>';
      if (i === breadcrumbArr.length - 1) {
        bc += `<span class="bc-current">${breadcrumbArr[i]}</span>`;
      } else {
        bc += `<span>${breadcrumbArr[i]}</span>`;
      }
    }
  }
  bc += '</div>';
  return `<div class="top-nav">
    ${bc}
    <div class="top-nav-right">
      <a href="../../个人中心/消息中心/pc_messages.html" class="nav-icon"><i class="fa-regular fa-bell"></i><span class="badge"></span></a>
      <a href="../../个人中心/通知公告/pc_notices.html" class="nav-icon"><i class="fa-regular fa-envelope"></i></a>
      <div class="user-info">
        <img class="user-avatar" src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=120&q=80" alt="">
        <span>${userName}</span>
      </div>
    </div>
  </div>`;
}

function initLayout(config) {
  const content = document.getElementById('page-content');
  if (!content) return;
  if (config && config.skipLayout) return;
  const contentHTML = content.innerHTML;
  const bc = config.breadcrumb || [];
  const wrap = document.createElement('div');
  wrap.className = 'layout-wrap';
  wrap.innerHTML = buildSidebar(config.active || '') +
    `<div class="layout-main">` +
    buildTopNav(bc, config.user) +
    `<div class="page-content">${contentHTML}</div></div>`;
  document.body.innerHTML = '';
  document.body.appendChild(wrap);
}

window.addEventListener('DOMContentLoaded', function() {
  if (window.__layoutConfig) initLayout(window.__layoutConfig);
});